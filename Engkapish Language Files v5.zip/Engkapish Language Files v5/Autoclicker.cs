﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

namespace Engkapish_DotNet
{
    public class Autoclicker
    {
        [DllImport("user32")]
        public static extern int SetCursorPos(int x, int y);
        private const int MOUSEEVENTF_ABSOLUTE = 0x8000;
        private const int MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const int MOUSEEVENTF_LEFTUP = 0x0004;
        private const int MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        private const int MOUSEEVENTF_MIDDLEUP = 0x0040;
        private const int MOUSEEVENTF_MOVE = 0x0001;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const int MOUSEEVENTF_RIGHTUP = 0x0010;
        private const int MOUSEEVENTF_XDOWN = 0x0080;
        private const int MOUSEEVENTF_XUP = 0x0100;
        private const int MOUSEEVENTF_WHEEL = 0x0800;
        private const int MOUSEEVENTF_HWHEEL = 0x01000;


        [DllImport("user32.dll",
            CharSet = CharSet.Auto, CallingConvention= CallingConvention.StdCall)]

public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons,
    int dwExtraInfo);

        public static void MouseClicker(bool isLeftClick, int milliseconds_between_clicks, int max_clicks)
        {
            int x = Cursor.Position.X;
            int y = Cursor.Position.Y;

            if (isLeftClick == true)
            {
                for (int i = 0; i <= max_clicks; i++)
                {
                Thread.Sleep(milliseconds_between_clicks);
                mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0);
                mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0);
                }
            }
            else if (isLeftClick == false)
            {
                for (int i = 0; i <= max_clicks; i++)
                {
                Thread.Sleep(milliseconds_between_clicks);
                mouse_event(MOUSEEVENTF_RIGHTDOWN, x, y, 0, 0);
                mouse_event(MOUSEEVENTF_RIGHTUP, x, y, 0, 0);
                }
            }
        }
    }
}

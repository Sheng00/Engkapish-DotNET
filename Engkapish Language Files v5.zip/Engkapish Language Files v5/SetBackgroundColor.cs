﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    public class SetBackgroundColor
    {
        public static void Red()
        {

                Console.BackgroundColor = ConsoleColor.Red;

        }
        public static void Green()
        {

                Console.BackgroundColor = ConsoleColor.Green;

        }
        public static void Blue()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.Blue;
            }
            
            {

            }
        }
        public static void Yellow()
        {

            {
                Console.BackgroundColor = ConsoleColor.Yellow;
            }
            
            {

            }
        }
        public static void Magenta()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.Magenta;
            }
            
            {

            }
        }
        public static void Purple()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.DarkMagenta;
            }
            
            {

            }
        }
        public static void Black()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.Black;
            }
            
            {

            }
        }
        public static void White()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.White;
            }
            
            {

            }
        }
        public static void Cyan()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.Cyan;
            }
            
            {

            }
        }
        public static void Grey()
        {
            
            {
                Console.BackgroundColor = ConsoleColor.Gray;
            }
            
            {

            }
        }
    }
}

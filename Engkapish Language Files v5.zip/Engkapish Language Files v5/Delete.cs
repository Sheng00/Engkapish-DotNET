﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engkapish_DotNet
{
    public class Delete
    {
        public static void file(string path)
        {
            File.Delete(path);
        }
        public static void directory(string path)
        {
            Directory.Delete(path);
        }
    }
}

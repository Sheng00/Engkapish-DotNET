﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    class SetForegroundColor
    {
        public static void Red()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            
            {

            }
        }
        public static void Green()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            
            {

            }
        }
        public static void Blue()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Blue;
            }
            
            {

            }
        }
        public static void Yellow()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            
            {

            }
        }
        public static void Magenta()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
            }
            
            {

            }
        }
        public static void Purple()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
            }
            
            {

            }
        }
        public static void Black()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Black;
            }
            
            {

            }
        }
        public static void White()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            
            {

            }
        }
        public static void Cyan()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
            }
            
            {

            }
        }
        public static void Grey()
        {
            
            {
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            
            {

            }
        }
    }
}

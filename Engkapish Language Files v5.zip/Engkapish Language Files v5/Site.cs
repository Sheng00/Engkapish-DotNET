﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    class Site
    {
        public static string location { get; set; }
        public static string text { get; set; }

        //public static string backgroundName { get; set; }
        //public static string buttonname { get; set; }
        public static void Start(string location_to_be_made)
        {
            location = location_to_be_made;
            text += "<html>";
        }
        public static void Center()
        {
            text += "<center>";
        }
        public static void EndCenter()
        {
            text += "</center>";
        }
        public static void Head(string title, string image_location)
        {
            text += "<head><link rel=\"icon\" type=\"image / gif / png\" href=\"" + image_location + "\">" + "<title>" + title + "</title></head>";
        }
        public static void StartBody()
        {
            text += "<body>";
        }
        public static void BodyBackgroundColor(string color)
        {
            text += "<body bgcolor=\"" + color + "\">";
        }
        public static void BodyBackgroundImage(string image_location)
        {
            text += $"<body background=\"{image_location}\">";
        }
        public static void AddFontSize(int size)
        {
            text += $"<font size=\"{size}\">";
        }
        public static void EndFont()
        {
            text += "</font>";
        }

        public static void image(string image_location)
        {
            text += $"<img src=\"{image_location}\" width=\"auto\" height=\"auto\">";
        }
        public class Buttons
        {
            public static void StartButton(string buttonName)
            {
                text += "<div class=\"" + buttonName + "\">";
            }

            public static void EndButton()
            {
                text += "</div>";
            }
            public static void AddButton(string buttonName, string Color1, string Color2, bool isCurved, string Text)
            {

                    text += Text;

                text += Environment.NewLine + "<style>" + Environment.NewLine +
                "." + buttonName + "{" + Environment.NewLine +

                    "background-color: " + Color1 + ";" + Environment.NewLine +
                    "color: " + Color2 + ";" + Environment.NewLine;
                    if (isCurved == true)
                {
                    text += "border-radius: " + "35px;";
                }
                    text += "} </style>";
            }
            public static void AhrefLinkedButton(string buttonName, string Color1, string Color2, bool isCurved, string link, string Text)
            {

                    text += "<a href=\"" + link + $"\" class=\"{buttonName}\">" + text + "</a>";
                text += Environment.NewLine + "<style>" + Environment.NewLine +
"." + buttonName + "{" + Environment.NewLine +

    "background-color: " + Color1 + ";" + Environment.NewLine +
    "color: " + Color2 + ";" + Environment.NewLine;
                if (isCurved == true)
                {
                    text += "border-radius: " + "35px;";
                }
                text += "} </style>";
            }
        }

        public class Text
        {
            public static void AddText(string Text)
            {
                text += Text;
            }
            public static void BlankLine()
            {
                text += "<br>";
            }
            public static void Background(string backgroundName, string Color1, string Color2, bool isCurved)
            {
                text += Environment.NewLine + "<style>" + Environment.NewLine +
                    "." + backgroundName +"{"+
                    Environment.NewLine + "background-color: " + Color1 + ";" +
                    Environment.NewLine + "color: " + Color2 + ";" + Environment.NewLine;
                if (isCurved == true)
                {
                    text += "border-radius: " + "35px;";
                }
                text += "}</style>";
            }
            public static void StartBackground(string backgroundName)
            {
                text += "<div class=\"" + backgroundName + "\">";
            }
            public static void EndBackground()
            {
                text += "</div>";
            }
        }

        public static void EndBody()
        {
            text += "</body>";
        }
        public static void End()
        {
            text += "</html>";
        }
        public static void Compile()
        {
            Write.ToFile(location + @"\HtmlSite.html", text);
            Process.Start(location + @"\HtmlSite.html");
        }
    }
}

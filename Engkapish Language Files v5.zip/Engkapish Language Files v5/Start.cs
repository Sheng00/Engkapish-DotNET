﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;

namespace Engkapish_DotNet
{
    public class Start
    {
        public static void Application(string Application_Location)
        {
            Process.Start(Application_Location);
        }

        public static void Shutdown_Sequence()
        {
            Process.Start("shutdown", "/s /t 0");
        }
        public static void Restart_Sequence()
        {
            Process.Start("shutdown", "/r /t 0");
        }
        private static int time { get; set; }
        private static bool displayCountDown { get; set; }
        private static bool playBeepWhenDone { get; set; }
        public static void CountDown(int Time, bool displayCountdown, bool Play_Beep_When_Done)
        {
            time = Time * 1000;
            if (Play_Beep_When_Done == true)
                playBeepWhenDone = true;
            if (Play_Beep_When_Done == false)
                playBeepWhenDone = false;

            if(displayCountdown == true)
            {
                displayCountDown = true;
            }
            if (displayCountdown == false)
            {
                displayCountDown = false;
            }
            Thread thd = new Thread(countdown);
            thd.Start();
        }

        private static async void countdown()
        {
            if (playBeepWhenDone == true)
            {
                if (displayCountDown == true)
                {
                    do
                    {
                        time -= 1000;
                        Clear.Screen();
                        Write.Text("Time remaining: " + time / 1000);
                        Thread.Sleep(1000);
                    } while (time > 0);
                    Play.Sound.Beep();
                    Play.Sound.Beep();
                    Play.Sound.Beep();

                }
                else
                {

                    do
                    {
                        time -= 1000;
                        Thread.Sleep(1000);
                    } while (time > 0);
                    Play.Sound.Beep();
                    Play.Sound.Beep();
                    Play.Sound.Beep();

                }
            }
            else
            {
                if (playBeepWhenDone == true)
                {

                    do
                    {
                        time -= 1000;
                        Thread.Sleep(1000);
                    } while (time > 0);
                    Play.Sound.Beep();
                    Play.Sound.Beep();
                    Play.Sound.Beep();
                }
            }
        }
    }
}

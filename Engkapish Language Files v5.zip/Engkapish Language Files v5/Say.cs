﻿using System.Speech.Synthesis;

namespace Engkapish_DotNet
{
    public class Say
    {
        private static SpeechSynthesizer SS = new SpeechSynthesizer();

        public static void Custom_Text(string text)
        {
            SS.SpeakAsync(text);
        }
        public static void Help()
        {
            SS.SpeakAsync("Help!");
        }
        public static void Whatsup()
        {
            SS.SpeakAsync("Whats Up?");
        }
        public static void Levi()
        {
            SS.SpeakAsync("Levi");
        }
        public static void Creator()
        {
            SS.SpeakAsync("The creator of Engkapish is Shaen Gignac!");
        }
    }
}

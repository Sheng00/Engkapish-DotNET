﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Mail;

namespace Engkapish_DotNet
{
    public class Write
    {
        public static void Email(string Subject, string Body, string Email_Address, string smtp_Server, int port, string email, string password, int amount)
        {
            try
            {
                for (int i = 0; i <= amount - 1; i++)
                {
                    MailMessage message = new MailMessage(email, Email_Address, Subject, Body);
                    NetworkCredential cred = new NetworkCredential(email, password);
                    SmtpClient client = new SmtpClient(smtp_Server, port);
                    client.EnableSsl = true;
                    client.UseDefaultCredentials = false;
                    client.Credentials = cred;
                    client.Send(message);
                }
            }
            catch(Exception ex)
            {
                Write.Text(ex.Message);
            }

        }

        public static string userResponse { get; set; }
        public static void GetResponse()
        {
            userResponse = Console.ReadLine();
        }
        public static string FileContents { get; set; }
        public static void FromFile(string location)
        {
            string Contents = File.ReadAllText(location);
            FileContents = Contents;
        }

        public static string[] FileLines { get; set; }
        public static void GetFileLines(string path)
        {
            FileLines = File.ReadAllLines(path);

        }
        public static void ToFile(string location, string contents)
        {
            File.WriteAllText(location, contents);
        }
        public static void HelloWorld()
        {
            Console.WriteLine("Hello World!");
        }
        public static void Text(string text)
        {
            Console.WriteLine(text);
        }
        public static void Blank()
        {
            Console.WriteLine();
        }
        public static void CreatorsWebsite()
        {
            Write.Text("http://engkapish.ml/");
            Start.Application("http://engkapish.ml/");
        }

        public static string Processes { get; set; }
        public static void CurrentProcesses(bool Only_Show_Names, bool write_data_to_screen)
        {
 
            if(Only_Show_Names == true)
            {
                Process[] processes = Process.GetProcesses();
                foreach (Process process in processes)
                {
                    if (write_data_to_screen == true)
                    {
                        Text(process.ToString());
                    }
                    Processes += process.ProcessName + Environment.NewLine;
                }
            }
            else
            {
                Process[] processes = Process.GetProcesses();
                foreach(Process process in processes)
                {
                    if (write_data_to_screen == true)
                    {
                        Text(process.ToString());
                    }
                    Processes += process.ProcessName + " | " + process.Id + Environment.NewLine;

                }
            }
            
        }
        public static void KillProcess(string Name)
        {
            Process[] processes = Process.GetProcesses();
            foreach(Process process in processes)
            {
                if(process.ProcessName == Name)
                {
                    process.Kill();
                }
            }
        }
    }
}

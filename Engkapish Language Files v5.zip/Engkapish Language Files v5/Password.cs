﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    class Password
    {
        public static void Lock(string message, string failMessage, string successMessage, string password)
        {

            string pass;
            Clear.Screen();
            Write.Text(message);
            pass = Console.ReadLine();
            if (pass == password)
            {
                Clear.Screen();
                Write.Text(successMessage);
            }
            else if (pass != password)
            {
                Clear.Screen();
                Write.Text(failMessage);
                Pause.Screen.onKeyPress(false);
                Password.Lock(message, failMessage, successMessage, password);
            }
        }
    }
}

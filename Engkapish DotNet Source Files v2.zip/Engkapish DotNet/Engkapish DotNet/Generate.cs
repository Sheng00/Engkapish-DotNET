﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    class Generate
    {
        public static void MixedString(int Amount, int Length)
        {
            StringBuilder sb = new StringBuilder();
            Random rand = new Random();
            for(int e = 0; e <= Amount; e++)
            {
                for(int i = 0; i <= Length - 1; i++)
                {
                    int num = rand.Next(0, 61);

                    switch(num)
                    {

                        case 0:
                            sb.Append("A");
                            break;
                        case 1:
                            sb.Append("B");

                            break;
                        case 2:
                            sb.Append("C");

                            break;
                        case 3:
                            sb.Append("D");

                            break;
                        case 4:
                            sb.Append("E");

                            break;
                        case 5:
                            sb.Append("F");

                            break;
                        case 6:
                            sb.Append("G");

                            break;
                        case 7:
                            sb.Append("H");

                            break;
                        case 8:
                            sb.Append("I");

                            break;
                        case 9:
                            sb.Append("J");

                            break;
                        case 10:
                            sb.Append("K");

                            break;
                        case 11:
                            sb.Append("L");

                            break;
                        case 12:
                            sb.Append("M");

                            break;
                        case 13:
                            sb.Append("N");

                            break;
                        case 14:
                            sb.Append("O");

                            break;
                        case 15:
                            sb.Append("P");

                            break;
                        case 16:
                            sb.Append("Q");

                            break;
                        case 17:
                            sb.Append("R");

                            break;
                        case 18:
                            sb.Append("S");

                            break;
                        case 19:
                            sb.Append("T");

                            break;
                        case 20:
                            sb.Append("U");

                            break;
                        case 21:
                            sb.Append("V");

                            break;
                        case 22:
                            sb.Append("W");

                            break;
                        case 23:
                            sb.Append("X");

                            break;
                        case 24:
                            sb.Append("Y");

                            break;
                        case 25:
                            sb.Append("Z");

                            break;
                        case 26:
                            sb.Append("a");

                            break;
                        case 27:
                            sb.Append("b");

                            break;
                        case 28:
                            sb.Append("c");

                            break;
                        case 29:
                            sb.Append("d");

                            break;
                        case 30:
                            sb.Append("e");

                            break;
                        case 31:
                            sb.Append("f");

                            break;
                        case 32:
                            sb.Append("g");

                            break;
                        case 33:
                            sb.Append("h");

                            break;
                        case 34:
                            sb.Append("i");

                            break;
                        case 35:
                            sb.Append("j");

                            break;
                        case 36:
                            sb.Append("k");

                            break;
                        case 37:
                            sb.Append("l");

                            break;
                        case 38:
                            sb.Append("m");

                            break;
                        case 39:
                            sb.Append("n");

                            break;
                        case 40:
                            sb.Append("o");

                            break;
                        case 41:
                            sb.Append("p");

                            break;
                        case 42:
                            sb.Append("q");

                            break;
                        case 43:
                            sb.Append("r");

                            break;
                        case 44:
                            sb.Append("s");

                            break;
                        case 45:
                            sb.Append("t");

                            break;
                        case 46:
                            sb.Append("u");

                            break;
                        case 47:
                            sb.Append("v");

                            break;
                        case 48:
                            sb.Append("w");

                            break;
                        case 49:
                            sb.Append("x");

                            break;
                        case 50:
                            sb.Append("y");

                            break;
                        case 51:
                            sb.Append("z");

                            break;
                        case 52:
                            sb.Append("1");
                            break;
                        case 53:
                            sb.Append("2");
                            break;
                        case 54:
                            sb.Append("3");
                            break;
                        case 55:
                            sb.Append("4");
                            break;
                        case 56:
                            sb.Append("5");
                            break;
                        case 57:
                            sb.Append("6");
                            break;
                        case 58:
                            sb.Append("7");
                            break;
                        case 59:
                            sb.Append("8");
                            break;
                        case 60:
                            sb.Append("9");
                            break;
                        case 61:
                            sb.Append("0");
                            break;
                    }
                }Console.WriteLine(sb.ToString());
                sb.Clear();
            }

        }
        public static void String(int Amount, int Length)
        {
            Random rand = new Random();
            StringBuilder sb = new StringBuilder();
            for (int e = 0; e <= Amount; e++)
            {
                for (int i = 0; i <= Length - 1; i++)
                {
                    int num = rand.Next(0, 51);
                    switch (num)
                    {
                        case 0:
                            sb.Append("A");
                            break;
                        case 1:
                            sb.Append("B");

                            break;
                        case 2:
                            sb.Append("C");

                            break;
                        case 3:
                            sb.Append("D");

                            break;
                        case 4:
                            sb.Append("E");

                            break;
                        case 5:
                            sb.Append("F");

                            break;
                        case 6:
                            sb.Append("G");

                            break;
                        case 7:
                            sb.Append("H");

                            break;
                        case 8:
                            sb.Append("I");

                            break;
                        case 9:
                            sb.Append("J");

                            break;
                        case 10:
                            sb.Append("K");

                            break;
                        case 11:
                            sb.Append("L");

                            break;
                        case 12:
                            sb.Append("M");

                            break;
                        case 13:
                            sb.Append("N");

                            break;
                        case 14:
                            sb.Append("O");

                            break;
                        case 15:
                            sb.Append("P");

                            break;
                        case 16:
                            sb.Append("Q");

                            break;
                        case 17:
                            sb.Append("R");

                            break;
                        case 18:
                            sb.Append("S");

                            break;
                        case 19:
                            sb.Append("T");

                            break;
                        case 20:
                            sb.Append("U");

                            break;
                        case 21:
                            sb.Append("V");

                            break;
                        case 22:
                            sb.Append("W");

                            break;
                        case 23:
                            sb.Append("X");

                            break;
                        case 24:
                            sb.Append("Y");

                            break;
                        case 25:
                            sb.Append("Z");

                            break;
                        case 26:
                            sb.Append("a");

                            break;
                        case 27:
                            sb.Append("b");

                            break;
                        case 28:
                            sb.Append("c");

                            break;
                        case 29:
                            sb.Append("d");

                            break;
                        case 30:
                            sb.Append("e");

                            break;
                        case 31:
                            sb.Append("f");

                            break;
                        case 32:
                            sb.Append("g");

                            break;
                        case 33:
                            sb.Append("h");

                            break;
                        case 34:
                            sb.Append("i");

                            break;
                        case 35:
                            sb.Append("j");

                            break;
                        case 36:
                            sb.Append("k");

                            break;
                        case 37:
                            sb.Append("l");

                            break;
                        case 38:
                            sb.Append("m");

                            break;
                        case 39:
                            sb.Append("n");

                            break;
                        case 40:
                            sb.Append("o");

                            break;
                        case 41:
                            sb.Append("p");

                            break;
                        case 42:
                            sb.Append("q");

                            break;
                        case 43:
                            sb.Append("r");

                            break;
                        case 44:
                            sb.Append("s");

                            break;
                        case 45:
                            sb.Append("t");

                            break;
                        case 46:
                            sb.Append("u");

                            break;
                        case 47:
                            sb.Append("v");

                            break;
                        case 48:
                            sb.Append("w");

                            break;
                        case 49:
                            sb.Append("x");

                            break;
                        case 50:
                            sb.Append("y");

                            break;
                        case 51:
                            sb.Append("z");

                            break;
                    }
                }Console.WriteLine(sb.ToString());
                sb.Clear();
            }
        }
        public static void Numbers(int Amount, int Length)
        {
            Random rand = new Random();
            StringBuilder sb = new StringBuilder();
            for (int e = 0; e <= Amount; e++)
            {
                for (int i = 0; i <= Length - 1; i++)
                {
                    int num = rand.Next(0, 9);
                    sb.Append(num);
                }
                Console.WriteLine(sb.ToString());
                sb.Clear();
            }
        }
    }
}

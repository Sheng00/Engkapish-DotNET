﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    public class Pause
    {

            public static void Program(int milliseconds_to_pause)
            {
                Thread.Sleep(milliseconds_to_pause);
            }
        public class Screen
        {
            public static void onEnter()
            {
                Console.ReadLine();
            }

            public static void onKeyPress(bool Display_Press_Any_Key)
            {
                if(Display_Press_Any_Key == true)
                {
                    Console.WriteLine("Press Any Key To Continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.ReadKey();
                }
            }
        }
    }
}

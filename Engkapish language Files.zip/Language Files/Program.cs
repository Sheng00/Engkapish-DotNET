﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Engkapish_DotNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Write.Text("Hello world!");
            Pause.Screen.onKeyPress(true);
            Write.CurrentProcesses(true);
            Pause.Screen.onEnter();
            
            /*Autoclicker.MouseClicker(true, 500, 99999); //Is leftClick, ms between, max amount

            Clear.Screen();

            Pause.Screen.onKeyPress(false); // Display "Press ANy Key"
            Pause.Screen.onEnter();

            Play.Sound.Beep();
            Play.Sound.Bell(false); // Loop
            Play.Sound.Bomb(false); // Loop
            Play.Sound.CrushingPlastic(false); // Loop
            Play.Sound.DemonGirl(false); // Loop
            Play.Sound.Meow(false); // Loop
            Play.Sound.Robot(false); // Loop
            Play.Sound.ShotgunReload(false); // Loop

            Say.Creator();
            Say.Custom_Text("Hello Levi Gallardo");
            Say.Help();
            Say.Levi();
            Say.Whatsup();

            SetBackgroundColor.Black(false); //Set color
            SetBackgroundColor.Blue(false); //Set color
            SetBackgroundColor.Cyan(false); //Set color
            SetBackgroundColor.Green(false); //Set color
            SetBackgroundColor.Grey(false); //Set color
            SetBackgroundColor.Magenta(false); //Set color
            SetBackgroundColor.Purple(false); //Set color
            SetBackgroundColor.Red(false); //Set color
            SetBackgroundColor.White(false); //Set color
            SetBackgroundColor.Yellow(false); //Set color

            SetForegroundColor.Black(false); //Set color
            SetForegroundColor.Blue(false); //Set color
            SetForegroundColor.Cyan(false); //Set color
            SetForegroundColor.Green(false); //Set color
            SetForegroundColor.Grey(false); //Set color
            SetForegroundColor.Magenta(false); //Set color
            SetForegroundColor.Purple(false); //Set color
            SetForegroundColor.Red(false); //Set color
            SetForegroundColor.White(false); //Set color
            SetForegroundColor.Yellow(false); //Set color

            Spam.Text("Spammer", 100, 1, true, "!"); // Text to spam, amount of spam, seconds between, create new line, prefix/special_text

            Write.Blank();
            Write.CurrentProcesses(true); // Show only names
            Write.KillProcess("Process Name"); // Kill process name
            Write.Text("Hello Levi Gallardo");*/
        }
    }
}

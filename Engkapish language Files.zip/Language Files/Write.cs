﻿using System;
using System.Diagnostics;

namespace Engkapish_DotNet
{
    public class Write
    {
        public static void Text(string text)
        {
            Console.WriteLine(text);
        }
        public static void Blank()
        {
            Console.WriteLine();
        }
        public static void CurrentProcesses(bool Only_Show_Names)
        {
            if(Only_Show_Names == true)
            {
                Process[] processes = Process.GetProcesses();
                foreach (Process process in processes)
                {
                    Console.WriteLine(process.ProcessName);
                }
            }
            else
            {
                Process[] processes = Process.GetProcesses();
                foreach(Process process in processes)
                {
                    Console.WriteLine(process.ProcessName + "|" + process.Id);
                }
            }
        }
        public static void KillProcess(string Name)
        {
            Process[] processes = Process.GetProcesses();
            foreach(Process process in processes)
            {
                if(process.ProcessName == Name)
                {
                    process.Kill();
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    class SetForegroundColor
    {
        public static void Red(bool T_F)
        {
            if(T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else
            {

            }
        }
        public static void Green(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            else
            {

            }
        }
        public static void Blue(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
            }
            else
            {

            }
        }
        public static void Yellow(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            else
            {

            }
        }
        public static void Magenta(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
            }
            else
            {

            }
        }
        public static void Purple(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
            }
            else
            {

            }
        }
        public static void Black(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else
            {

            }
        }
        public static void White(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {

            }
        }
        public static void Cyan(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
            }
            else
            {

            }
        }
        public static void Grey(bool T_F)
        {
            if (T_F == true)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            else
            {

            }
        }
    }
}

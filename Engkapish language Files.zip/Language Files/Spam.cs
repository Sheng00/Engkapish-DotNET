﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Engkapish_DotNet
{

    public class Spam
    {
        public static void Text(string text,int max_sends,int time_between_send, bool Make_New_Line, string special_type_keycode)
        {
            time_between_send = time_between_send * 1000;
            for (int i = 0; i <= max_sends; i++)
            {
                Thread.Sleep(time_between_send);
                SendKeys.SendWait(special_type_keycode);

                if (Make_New_Line == true)
                {
                    SendKeys.SendWait(text);
                    SendKeys.SendWait("^{ENTER}");
                }
                else if(Make_New_Line == false)
                {
                    SendKeys.SendWait(text);
                }
            }
        }
    }
}

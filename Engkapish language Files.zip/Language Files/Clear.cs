﻿using System;

namespace Engkapish_DotNet
{
    class Clear
    {
        public static void Screen()
        {
            Console.Clear();
        }
    }
}

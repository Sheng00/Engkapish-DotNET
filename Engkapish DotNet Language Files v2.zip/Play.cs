﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    public class Play
    {
        
        public class Sound
        {
            public static void Beep()
            {
                Console.Beep();
            }
            public static void Meow(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach(var file in files)
                {
                    if(file.FullName.Contains("catMeow"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void Bell(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("serviceBell"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void Robot(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("Robot"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void DemonGirl(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("demonGirl"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void CrushingPlastic(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("crushingPlastic"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void Bomb(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("bomb"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
            public static void ShotgunReload(bool Loop)
            {
                DirectoryInfo di = new DirectoryInfo(Directory.GetCurrentDirectory());

                var files = di.Parent.Parent.GetFiles();
                foreach (var file in files)
                {
                    if (file.FullName.Contains("shotgunReload"))
                    {
                        SoundPlayer typewriter = new SoundPlayer();
                        typewriter.SoundLocation = file.FullName;
                        if (Loop == true)
                        {
                            typewriter.PlayLooping();
                        }
                        else
                        {
                            typewriter.PlaySync();
                        }
                    }
                }
            }
        }

    }
}

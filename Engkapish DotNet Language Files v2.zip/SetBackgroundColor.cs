﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engkapish_DotNet
{
    public class SetBackgroundColor
    {
        public static void Red(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Red;
            }
            else
            {
                
            }
        }
        public static void Green(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Green;
            }
            else
            {

            }
        }
        public static void Blue(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Blue;
            }
            else
            {

            }
        }
        public static void Yellow(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Yellow;
            }
            else
            {

            }
        }
        public static void Magenta(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Magenta;
            }
            else
            {

            }
        }
        public static void Purple(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.DarkMagenta;
            }
            else
            {

            }
        }
        public static void Black(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Black;
            }
            else
            {

            }
        }
        public static void White(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.White;
            }
            else
            {

            }
        }
        public static void Cyan(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Cyan;
            }
            else
            {

            }
        }
        public static void Grey(bool T_F)
        {
            if (T_F == true)
            {
                Console.BackgroundColor = ConsoleColor.Gray;
            }
            else
            {

            }
        }
    }
}

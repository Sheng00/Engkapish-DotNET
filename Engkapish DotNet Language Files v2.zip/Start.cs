﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
namespace Engkapish_DotNet
{
    public class Start
    {
        public static void Application(string Application_Location)
        {
            Process.Start(Application_Location);
        }

        public static void Shutdown_Sequence()
        {
            Process.Start("shutdown", "/s /t 0");
        }
        public static void Restart_Sequence()
        {
            Process.Start("shutdown", "/r /t 0");
        }
    }
}
